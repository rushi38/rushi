# AndroidEatIt
tested on API 26, nexus4

 ● Used Firebase to store restaurant data, Applied MVC pattern design style for client
side & server side.

 ● Provided sign in/sign up function, menu and food list loading, orders management
process, and notifications for users

 ● Applied multi-threading manipulation, synchronization, JUnit Runner test as back end
