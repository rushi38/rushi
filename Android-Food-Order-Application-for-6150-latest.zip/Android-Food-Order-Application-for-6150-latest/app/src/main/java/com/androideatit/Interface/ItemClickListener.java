package com.androideatit.Interface;

import android.view.View;

/**
 * Created by 123456 on 2017/11/17.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
